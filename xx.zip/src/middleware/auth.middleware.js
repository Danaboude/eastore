
const jwt = require('jsonwebtoken');
const { AppError } = require('./error.middleware');
const { pool } = require('../config/database');
const { logger } = require('../utils/logger');
require('dotenv').config();

// Authentication middleware
const authenticate = async (req, res, next) => {
  try {
    // Get token from header
    const authHeader = req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('Access token required', 401);
    }

    const token = authHeader.split(' ')[1];

    if (!token) {
      throw new AppError('Access token required', 401);
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Check if user still exists
    const [users] = await pool.execute(
      'SELECT id, full_name, email, role, is_active FROM users WHERE id = ?',
      [decoded.user.id]
    );

    if (users.length === 0) {
      throw new AppError('User no longer exists', 401);
    }

    const user = users[0];

    if (!user.is_active) {
      throw new AppError('User account is deactivated', 401);
    }

    // Check if user changed password after token was issued
    if (decoded.iat < user.passwordChangedAt) {
      throw new AppError('User recently changed password! Please log in again', 401);
    }

    // Grant access to protected route
    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      next(new AppError('Invalid token', 401));
    } else if (error.name === 'TokenExpiredError') {
      next(new AppError('Token expired', 401));
    } else {
      next(error);
    }
  }
};

// Optional authentication middleware (for routes that can work with or without auth)
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next();
    }

    const token = authHeader.split(' ')[1];
    
    if (!token) {
      return next();
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    const [users] = await pool.execute(
      'SELECT id, full_name, email, role, is_active FROM users WHERE id = ?',
      [decoded.user.id]
    );

    if (users.length > 0 && users[0].is_active) {
      req.user = users[0];
    }
    
    next();
  } catch (error) {
    // Silently continue without authentication
    next();
  }
};

// Generate JWT token
const generateToken = (user) => {
  return jwt.sign(
    { 
      user: { 
        id: user.id,
        email: user.email,
        role: user.role 
      } 
    },
    process.env.JWT_SECRET,
    { 
      expiresIn: process.env.JWT_EXPIRES_IN || '7d' 
    }
  );
};

// Generate refresh token
const generateRefreshToken = (user) => {
  return jwt.sign(
    { 
      user: { 
        id: user.id,
        email: user.email 
      } 
    },
    process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET,
    { 
      expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d' 
    }
  );
};

module.exports = {
  authenticate,
  optionalAuth,
  generateToken,
  generateRefreshToken
};
