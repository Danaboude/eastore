const { AppError } = require('./error.middleware');
const { pool } = require('../config/database');

// Middleware to check for specific roles
const checkRole = (...allowedRoles) => {
  return (req, res, next) => {
    try {
      if (!req.user) {
        throw new AppError('Authentication required', 401);
      }

      if (!allowedRoles.includes(req.user.role)) {
        throw new AppError('Forbidden: You do not have the required permissions', 403);
      }

      next();
    } catch (error) {
      next(error);
    }
  };
};

// Middleware to check for admin role
const requireAdmin = checkRole('admin');

// Middleware to check for leader or admin role
const requireLeader = checkRole('admin', 'leader');

// Middleware to check for customer role
const requireCustomer = checkRole('customer');

// Middleware to check specific permissions
const checkPermission = (permissionCode) => {
  return async (req, res, next) => {
    try {
      if (!req.user) {
        throw new AppError('Authentication required', 401);
      }

      // Admin has all permissions
      if (req.user.role === 'admin') {
        return next();
      }

      // Check if user has specific permission
      const [permissions] = await pool.execute(
        `SELECT p.code 
         FROM permissions p 
         JOIN role_permissions rp ON p.id = rp.permission_id 
         WHERE rp.role = ? AND p.code = ?`,
        [req.user.role, permissionCode]
      );

      if (permissions.length === 0) {
        throw new AppError('Forbidden: You do not have the required permissions', 403);
      }

      next();
    } catch (error) {
      next(error);
    }
  };
};

// Common permission checks
const canReadOrders = checkPermission('orders.read');
const canWriteOrders = checkPermission('orders.write');
const canReadUsers = checkPermission('users.read');
const canWriteUsers = checkPermission('users.write');

// Middleware to check if user can access their own resource or has admin/leader role
const canAccessResource = (resourceUserIdField = 'user_id') => {
  return (req, res, next) => {
    try {
      if (!req.user) {
        throw new AppError('Authentication required', 401);
      }

      // Admin and leader can access all resources
      if (['admin', 'leader'].includes(req.user.role)) {
        return next();
      }

      // Customer can only access their own resources
      const resourceUserId = req.params[resourceUserIdField] || req.body[resourceUserIdField];
      
      if (resourceUserId && resourceUserId !== req.user.id) {
        throw new AppError('Forbidden: You can only access your own resources', 403);
      }

      next();
    } catch (error) {
      next(error);
    }
  };
};

module.exports = {
  checkRole,
  requireAdmin,
  requireLeader,
  requireCustomer,
  checkPermission,
  canReadOrders,
  canWriteOrders,
  canReadUsers,
  canWriteUsers,
  canAccessResource
};
