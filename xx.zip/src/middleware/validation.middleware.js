const Joi = require('joi');
const { AppError } = require('./error.middleware');

// Generic validation middleware
const validate = (schema) => {
  return (req, res, next) => {
    try {
      const { error, value } = schema.validate(req.body, {
        abortEarly: false,
        stripUnknown: true,
        allowUnknown: true
      });

      if (error) {
        const errorMessage = error.details
          .map(detail => detail.message)
          .join(', ');
        throw new AppError(`Validation error: ${errorMessage}`, 400);
      }

      // Replace req.body with validated data
      req.body = value;
      next();
    } catch (error) {
      next(error);
    }
  };
};

// Validation schemas
const schemas = {
  // User registration
  userRegistration: Joi.object({
    full_name: Joi.string().min(2).max(255).required()
      .messages({
        'string.min': 'Full name must be at least 2 characters long',
        'string.max': 'Full name cannot exceed 255 characters',
        'any.required': 'Full name is required'
      }),
    email: Joi.string().email().required()
      .messages({
        'string.email': 'Please provide a valid email address',
        'any.required': 'Email is required'
      }),
    phone: Joi.string().pattern(/^[+]?[\d\s\-\(\)]+$/).optional()
      .messages({
        'string.pattern.base': 'Please provide a valid phone number'
      }),
        password: Joi.string().min(8).required()
      .messages({
        'string.min': 'Password must be at least 8 characters long',
        'any.required': 'Password is required'
      }),
    role: Joi.string().valid('customer', 'leader', 'admin').default('customer')
      .messages({
        'any.only': 'Role must be one of: customer, leader, admin'
      })
  }),

  // User login
  userLogin: Joi.object({
    email: Joi.string().email().required()
      .messages({
        'string.email': 'Please provide a valid email address',
        'any.required': 'Email is required'
      }),
    password: Joi.string().required()
      .messages({
        'any.required': 'Password is required'
      })
  }),

  // User update
  userUpdate: Joi.object({
    full_name: Joi.string().min(2).max(255).optional()
      .messages({
        'string.min': 'Full name must be at least 2 characters long',
        'string.max': 'Full name cannot exceed 255 characters'
      }),
    phone: Joi.string().pattern(/^[+]?[\d\s\-\(\)]+$/).optional()
      .messages({
        'string.pattern.base': 'Please provide a valid phone number'
      }),
        password: Joi.string().min(8).optional()
      .messages({
        'string.min': 'Password must be at least 8 characters long'
      })
  }),

  // Cart item
  cartItem: Joi.object({
    provider: Joi.string().valid('amazon', 'shein').required()
      .messages({
        'any.only': 'Provider must be either amazon or shein',
        'any.required': 'Provider is required'
      }),
    product_url: Joi.string().uri().required()
      .messages({
        'string.uri': 'Please provide a valid product URL',
        'any.required': 'Product URL is required'
      }),
    quantity: Joi.number().integer().min(1).max(9999).required()
      .messages({
        'number.base': 'Quantity must be a number',
        'number.integer': 'Quantity must be a whole number',
        'number.min': 'Quantity must be at least 1',
        'number.max': 'Quantity cannot exceed 9999',
        'any.required': 'Quantity is required'
      }),
    title_snapshot: Joi.string().max(1000).optional()
      .messages({
        'string.max': 'Title snapshot cannot exceed 1000 characters'
      }),
    price_snapshot: Joi.number().precision(2).min(0).optional()
      .messages({
        'number.base': 'Price must be a number',
        'number.precision': 'Price can have maximum 2 decimal places',
        'number.min': 'Price cannot be negative'
      }),
    currency: Joi.string().length(3).optional()
      .messages({
        'string.length': 'Currency must be exactly 3 characters (e.g., USD, EUR)'
      }),
    attributes: Joi.object().required()
      .messages({
        'any.required': 'Product attributes are required'
      }),
    note: Joi.string().max(2000).optional()
      .messages({
        'string.max': 'Note cannot exceed 2000 characters'
      })
  }),

  // Order creation
  order: Joi.object({
    cart_id: Joi.string().uuid().required()
      .messages({
        'string.guid': 'Cart ID must be a valid UUID',
        'any.required': 'Cart ID is required'
      }),
    shipping: Joi.number().precision(2).min(0).default(0)
      .messages({
        'number.base': 'Shipping cost must be a number',
        'number.precision': 'Shipping cost can have maximum 2 decimal places',
        'number.min': 'Shipping cost cannot be negative'
      }),
    tax: Joi.number().precision(2).min(0).default(0)
      .messages({
        'number.base': 'Tax must be a number',
        'number.precision': 'Tax can have maximum 2 decimal places',
        'number.min': 'Tax cannot be negative'
      }),
    currency: Joi.string().length(3).default('AED') 
      .messages({
        'string.length': 'Currency must be exactly 3 characters (e.g., AED, USD)'
      }),
    payment_type: Joi.string().valid('cash', 'visa', 'mastercard').required() 
      .messages({
        'any.only': 'Payment type must be one of: cash, visa, mastercard',
        'any.required': 'Payment type is required'
      }),
    shipping_address_line1: Joi.string().max(255).required() 
      .messages({
        'string.max': 'Shipping address line 1 cannot exceed 255 characters',
        'any.required': 'Shipping address line 1 is required'
      }),
    shipping_city: Joi.string().max(255).required()
      .messages({
        'string.max': 'Shipping city cannot exceed 255 characters',
        'any.required': 'Shipping city is required'
      }),
    phone_number: Joi.string().pattern(/^[+]?[\d\s\-\(\)]+$/).required() 
      .messages({
        'string.pattern.base': 'Please provide a valid phone number',
        'any.required': 'Phone number is required'
      }),
    name: Joi.string().max(255).required() 
      .messages({
        'string.max': 'Name cannot exceed 255 characters',
        'any.required': 'Name is required'
      })
  }),

  // Order item update
  orderItemUpdate: Joi.object({
    id: Joi.string().uuid().required()
      .messages({
        'string.guid': 'Item ID must be a valid UUID',
        'any.required': 'Item ID is required'
      }),
    title_snapshot: Joi.string().max(1000).optional()
      .messages({
        'string.max': 'Title snapshot cannot exceed 1000 characters'
      }),
    price_snapshot: Joi.number().precision(2).min(0).optional()
      .messages({
        'number.base': 'Price must be a number',
        'number.precision': 'Price can have maximum 2 decimal places',
        'number.min': 'Price cannot be negative'
      }),
    quantity: Joi.number().integer().min(1).max(9999).optional()
      .messages({
        'number.base': 'Quantity must be a number',
        'number.integer': 'Quantity must be a whole number',
        'number.min': 'Quantity must be at least 1',
        'number.max': 'Quantity cannot exceed 9999'
      }),
  }),

  // Service request
  serviceRequest: Joi.object({
    category: Joi.string().valid('app', 'website', 'other').required()
      .messages({
        'any.only': 'Category must be one of: app, website, other',
        'any.required': 'Category is required'
      }),
    note: Joi.string().max(2000).optional()
      .messages({
        'string.max': 'Note cannot exceed 2000 characters'
      })
  }),

  // Service request note
  serviceRequestNote: Joi.object({
    body: Joi.string().min(1).max(2000).required()
      .messages({
        'string.min': 'Note body cannot be empty',
        'string.max': 'Note body cannot exceed 2000 characters',
        'any.required': 'Note body is required'
      })
  }),

  // Pagination
  pagination: Joi.object({
    page: Joi.number().integer().min(1).default(1)
      .messages({
        'number.base': 'Page must be a number',
        'number.integer': 'Page must be a whole number',
        'number.min': 'Page must be at least 1'
      }),
    limit: Joi.number().integer().min(1).max(100).default(10)
      .messages({
        'number.base': 'Limit must be a number',
        'number.integer': 'Limit must be a whole number',
        'number.min': 'Limit must be at least 1',
        'number.max': 'Limit cannot exceed 100'
      }),
    sort_by: Joi.string().valid('created_at', 'updated_at', 'id').default('created_at')
      .messages({
        'any.only': 'Sort by must be one of: created_at, updated_at, id'
      }),
    sort_order: Joi.string().valid('asc', 'desc').default('desc')
      .messages({
        'any.only': 'Sort order must be either asc or desc'
      })
  })
};

module.exports = {
  validate,
  schemas
};

