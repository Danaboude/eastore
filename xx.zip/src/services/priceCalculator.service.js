const ServiceQuestion = require('../api/models/serviceQuestion.model');
const { AppError } = require('../middleware/error.middleware');

/**
 * Calculates the estimated price for a service request based on user answers.
 *
 * @param {string} category - The service category ('app', 'website', 'other').
 * @param {Array<Object>} answers - An array of answer objects, e.g., [{ question_id: 1, answer_text: '...' }].
 * @returns {Promise<number>} - The calculated estimated price.
 */
async function calculateEstimatedPrice(category, answers) {
  if (!category || !answers || !Array.isArray(answers)) {
    throw new AppError('Category and answers are required for price calculation.', 400);
  }

  const questions = await ServiceQuestion.findByCategory(category);
  if (!questions || questions.length === 0) {
    return 0;
  }

  let basePrice = 0;
  const percentageModifiers = [];

  for (const answer of answers) {
    const question = questions.find(q => q.id === answer.question_id);
    if (!question || !question.price_data) {
      continue;
    }

    const priceData = typeof question.price_data === 'string'
      ? JSON.parse(question.price_data)
      : question.price_data;

    const userAnswer = parseAnswer(answer.answer_text);

    // Handle fixed price options
    if (priceData.options && priceData.options[userAnswer.value]) {
      const optionPrice = priceData.options[userAnswer.value];
      if (typeof optionPrice === 'number') {
        basePrice += optionPrice;
      } else if (typeof optionPrice === 'object' && optionPrice.type === 'percentage') {
        percentageModifiers.push(optionPrice.value);
      }
    }
    // Handle tiered pricing (for numeric/text inputs)
    else if (priceData.type === 'tiered') {
      const numericValue = parseInt(userAnswer.value, 10);
      if (!isNaN(numericValue)) {
        let tierPrice = 0;
        const tier = priceData.tiers.find(t =>
          (t.min === undefined || numericValue >= t.min) &&
          (t.max === undefined || numericValue <= t.max)
        );

        if (tier) {
          tierPrice = tier.price;
        } else if (priceData.per_unit) {
          // Calculate price for values exceeding the defined tiers
          const maxTier = Math.max(...priceData.tiers.map(t => t.max).filter(m => m !== undefined));
          if (numericValue > maxTier) {
             const baseTier = priceData.tiers.find(t=>t.max === maxTier);
             if(baseTier){
                tierPrice = baseTier.price + (numericValue - maxTier) * priceData.per_unit;
             } else {
                tierPrice = numericValue * priceData.per_unit;
             }
          }
        }
        basePrice += tierPrice;
      }
    }
  }

  // Apply percentage modifiers to the total base price
  let finalPrice = basePrice;
  for (const modifier of percentageModifiers) {
    finalPrice += finalPrice * modifier;
  }

  return parseFloat(finalPrice.toFixed(2));
}

/**
 * Parses the answer string, which might be a simple string or a JSON string with a 'value' field.
 * @param {string} answerText - The raw answer text.
 * @returns {{value: string, note: string|null}}
 */
function parseAnswer(answerText) {
  try {
    const parsed = JSON.parse(answerText);
    if (typeof parsed === 'object' && parsed.value) {
      return { value: parsed.value.toString(), note: parsed.note || null };
    }
  } catch (e) {
    // Not a JSON string, treat it as a simple string value.
  }
  return { value: answerText.toString(), note: null };
}

module.exports = { calculateEstimatedPrice };
