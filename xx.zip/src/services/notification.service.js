
const admin = require('firebase-admin');
const path = require('path');
const { logger } = require('../utils/logger');
const FcmTokenModel = require('../api/models/fcmToken.model');

const serviceAccountPath = path.join(__dirname, '../config/firebase-service-account.json');

try {
  const serviceAccount = require(serviceAccountPath);
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: serviceAccount.project_id
  });
  logger.info('Firebase Admin SDK initialized successfully.');
} catch (error) {
  logger.error('Firebase Admin SDK initialization failed. Please ensure firebase-service-account.json exists in src/config. Error:', error.message);
}

class NotificationService {
  static async sendToUser(userId, notification, data = {}) {
    try {
      const tokens = await FcmTokenModel.findByUserId(userId);
      if (tokens.length === 0) {
        logger.warn(`No FCM tokens found for user ${userId}. Notification not sent.`);
        return;
      }

      const messages = tokens.map(token => ({
        notification,
        data,
        token: token,
      }));

      const response = await admin.messaging().sendEach(messages);
      logger.info(`Successfully sent notification to user ${userId}: ${response.successCount} messages`);
      if (response.failureCount > 0) {
        logger.error(`Failed to send notification to ${response.failureCount} tokens for user ${userId}.`);
      }
    } catch (error) {
      logger.error(`Error sending notification to user ${userId}:`, error);
    }
  }

  static async sendToAdminsAndLeaders(notification, data = {}) {
    try {
        const tokens = await FcmTokenModel.findAdminsAndLeadersTokens();
        if (tokens.length === 0) {
            logger.warn(`No FCM tokens found for admins or leaders. Notification not sent.`);
            return;
        }

        const messages = tokens.map(token => ({
            notification,
            data,
            token: token,
        }));

        const messageChunks = [];
        for (let i = 0; i < messages.length; i += 500) {
            messageChunks.push(messages.slice(i, i + 500));
        }

        for (const chunk of messageChunks) {
            const response = await admin.messaging().sendEach(chunk);
            logger.info(`Successfully sent notifications to ${response.successCount} admins/leaders.`);
            if (response.failureCount > 0) {
                logger.error(`Failed to send notifications to ${response.failureCount} admin/leader tokens.`);
            }
        }
    } catch (error) {
        logger.error(`Error sending notification to admins and leaders:`, error);
    }
  }
}

module.exports = NotificationService;
