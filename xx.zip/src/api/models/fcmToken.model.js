const { pool } = require('../../config/database');
const { logger } = require('../../utils/logger');

class FcmTokenModel {
  static async createOrUpdate(userId, token) {
    try {
      // Check if the token already exists for any user
      const [existing] = await pool.execute('SELECT * FROM fcm_tokens WHERE token = ?', [token]);

      if (existing.length > 0) {
        // If it exists, but for a different user, update the user_id
        if (existing[0].user_id !== userId) {
          await pool.execute('UPDATE fcm_tokens SET user_id = ?, created_at = NOW() WHERE token = ?', [userId, token]);
          logger.info(`FCM token ownership updated for user ${userId}`);
        } else {
            await pool.execute('UPDATE fcm_tokens SET created_at = NOW() WHERE token = ?', [token]);
        }
      } else {
        // If the token doesn't exist at all, insert it
        await pool.execute(
          'INSERT INTO fcm_tokens (user_id, token) VALUES (?, ?)',
          [userId, token]
        );
        logger.info(`New FCM token stored for user ${userId}`);
      }
      return { success: true };
    } catch (error) {
      logger.error('Error creating or updating FCM token:', error.message);
      throw error;
    }
  }

  static async findByUserId(userId) {
    try {
      const [rows] = await pool.execute('SELECT token FROM fcm_tokens WHERE user_id = ?', [userId]);
      return rows.map(row => row.token);
    } catch (error) {
      logger.error('Error finding FCM tokens by user ID:', error.message);
      throw error;
    }
  }

  static async findByUserIds(userIds) {
    if (!userIds || userIds.length === 0) {
      return [];
    }
    try {
      const placeholders = userIds.map(() => '?').join(',');
      const [rows] = await pool.execute(`SELECT token FROM fcm_tokens WHERE user_id IN (${placeholders})`, userIds);
      return rows.map(row => row.token);
    } catch (error) {
      logger.error('Error finding FCM tokens by user IDs:', error.message);
      throw error;
    }
  }
  
  static async findAdminsAndLeadersTokens() {
    try {
      const [rows] = await pool.execute("SELECT token FROM fcm_tokens WHERE user_id IN (SELECT id FROM users WHERE role IN ('admin', 'leader'))");
      return rows.map(row => row.token);
    } catch (error) {
      logger.error('Error finding admin and leader FCM tokens:', error.message);
      throw error;
    }
  }
}

module.exports = FcmTokenModel;
