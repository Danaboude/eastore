
const { pool } = require('../../config/database');
const { v4: uuidv4 } = require('uuid');

class ServiceRequestModel {
  static async create(userId, category, note, estimatedPrice = 0, currency = 'USD') {
    const id = uuidv4();
    const [result] = await pool.execute(
      'INSERT INTO service_requests (id, user_id, category, note, estimated_price, currency) VALUES (?, ?, ?, ?, ?, ?)',
      [id, userId, category, note, estimatedPrice, currency]
    );
    return { id, userId, category, note, status: 'open', estimated_price: estimatedPrice, currency };
  }

  static async findByUserId(userId) {
    const [rows] = await pool.execute('SELECT *, estimated_price, currency FROM service_requests WHERE user_id = ? ORDER BY created_at DESC', [userId]);
    return rows;
  }

  static async findById(id) {
    const [rows] = await pool.execute('SELECT *, estimated_price, currency FROM service_requests WHERE id = ?', [id]);
    return rows[0];
  }

  static async updateStatus(id, status) {
    const [result] = await pool.execute(
      'UPDATE service_requests SET status = ? WHERE id = ?',
      [status, id]
    );
    return result.affectedRows > 0;
  }

  static async findAll(options = {}) {
    const {
      page = 1,
      limit = 10,
      search,
      status,
      sort_by = 'created_at',
      sort_order = 'desc'
    } = options;

    let baseQuery = 'SELECT sr.*, u.full_name as user_name, u.email as user_email, u.phone as user_phone FROM service_requests sr LEFT JOIN users u ON sr.user_id = u.id';
    let countQuery = 'SELECT COUNT(*) as total FROM service_requests sr LEFT JOIN users u ON sr.user_id = u.id';
    
    let whereClauses = [];
    let queryParams = [];

    if (search) {
      whereClauses.push('(sr.id LIKE ? OR u.full_name LIKE ? OR u.email LIKE ? OR sr.category LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    if (status) {
      whereClauses.push('sr.status = ?');
      queryParams.push(status);
    }

    if (whereClauses.length > 0) {
      const whereString = ' WHERE ' + whereClauses.join(' AND ');
      baseQuery += whereString;
      countQuery += whereString;
    }

    const [countResult] = await pool.execute(countQuery, queryParams);
    const total = countResult[0].total;

    const offset = (page - 1) * limit;
    baseQuery += ` ORDER BY ${sort_by} ${sort_order.toUpperCase()} LIMIT ? OFFSET ?`;
    queryParams.push(parseInt(limit), offset);

    const [rows] = await pool.execute(baseQuery, queryParams);

    return {
      requests: rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: total,
        totalPages: Math.ceil(total / limit)
      }
    };
  }
  }


module.exports = ServiceRequestModel;
