
const { pool } = require('../../config/database');
const { v4: uuidv4 } = require('uuid');
const { logger } = require('../../utils/logger');

class UserModel {
  // Create a new user
  static async create(userData) {
    try {
      const {
        full_name,
        email,
        phone,
        password_hash,
        password_algo = 'bcrypt',
        role = 'customer',
        google_sub = null
      } = userData;

      const id = uuidv4();
      const now = new Date();

      const [result] = await pool.execute(
        `INSERT INTO users (id, full_name, email, phone, password_hash, password_algo, role, google_sub, created_at, updated_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, full_name, email, phone, password_hash, password_algo, role, google_sub, now, now]
      );

      if (result.affectedRows === 0) {
        throw new Error('Failed to create user');
      }

      // Return the created user
      return await this.findById(id);
    } catch (error) {
      logger.error('Error creating user:', error.message);
      throw error;
    }
  }

  // Find user by email
  static async findByEmail(email) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM users WHERE email = ?',
        [email]
      );
      return rows[0] || null;
    } catch (error) {
      logger.error('Error finding user by email:', error.message);
      throw error;
    }
  }

  // Find user by ID
  static async findById(id) {
    try {
      const [rows] = await pool.execute(
        'SELECT id, full_name, email, phone, role, is_active, google_sub, created_at, updated_at FROM users WHERE id = ?',
        [id]
      );
      return rows[0] || null;
    } catch (error) {
      logger.error('Error finding user by ID:', error.message);
      throw error;
    }
  }

  // Find user by ID with password (for authentication)
  static async findByIdWithPassword(id) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM users WHERE id = ?',
        [id]
      );
      return rows[0] || null;
    } catch (error) {
      logger.error('Error finding user by ID with password:', error.message);
      throw error;
    }
  }

  // Find user by Google sub
  static async findByGoogleSub(googleSub) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM users WHERE google_sub = ?',
        [googleSub]
      );
      return rows[0] || null;
    } catch (error) {
      logger.error('Error finding user by Google sub:', error.message);
      throw error;
    }
  }

  // Update user
  static async update(id, updateData) {
    try {
      const fields = Object.keys(updateData);
      if (fields.length === 0) {
        throw new Error('No fields to update');
      }

      const setClause = fields.map(field => `${field} = ?`).join(', ');
      const values = [...Object.values(updateData), new Date(), id];

      const [result] = await pool.execute(
        `UPDATE users SET ${setClause}, updated_at = ? WHERE id = ?`,
        values
      );

      if (result.affectedRows === 0) {
        throw new Error('User not found or no changes made');
      }

      // Return the updated user
      return await this.findById(id);
    } catch (error) {
      logger.error('Error updating user:', error.message);
      throw error;
    }
  }

  // Update last login
  static async updateLastLogin(id) {
    try {
      await pool.execute(
        'UPDATE users SET updated_at = ? WHERE id = ?',
        [new Date(), id]
      );
    } catch (error) {
      logger.error('Error updating last login:', error.message);
      // Don't throw error for this non-critical operation
    }
  }

  // Get all users with pagination and filters
  static async findAll(options = {}) {
    try {
      const {
        page = 1,
        limit = 10,
        search,
        role,
        is_active,
        sort_by = 'created_at',
        sort_order = 'desc'
      } = options;

      let baseQuery = 'SELECT id, full_name, email, phone, role, is_active, created_at, updated_at FROM users';
      let countQuery = 'SELECT COUNT(*) as total FROM users';
      
      let whereClauses = [];
      let queryParams = [];

      if (search) {
        whereClauses.push('(full_name LIKE ? OR email LIKE ? OR phone LIKE ?)');
        queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
      }
      if (role) {
        whereClauses.push('role = ?');
        queryParams.push(role);
      }
      if (is_active !== undefined) {
        whereClauses.push('is_active = ?');
        queryParams.push(is_active);
      }

      if (whereClauses.length > 0) {
        const whereString = ' WHERE ' + whereClauses.join(' AND ');
        baseQuery += whereString;
        countQuery += whereString;
      }

      const [countResult] = await pool.execute(countQuery, queryParams);
      const total = countResult[0].total;

      const offset = (page - 1) * limit;
      baseQuery += ` ORDER BY ${sort_by} ${sort_order.toUpperCase()} LIMIT ? OFFSET ?`;
      queryParams.push(parseInt(limit), offset);

      const [rows] = await pool.execute(baseQuery, queryParams);

      return {
        users: rows,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: total,
          totalPages: Math.ceil(total / limit)
        }
      };
    } catch (error) {
      logger.error('Error finding all users:', error.message);
      throw error;
    }
  }

  // Delete user (soft delete)
  static async delete(id) {
    try {
      const [result] = await pool.execute(
        'UPDATE users SET is_active = false, updated_at = ? WHERE id = ?',
        [new Date(), id]
      );

      if (result.affectedRows === 0) {
        throw new Error('User not found');
      }

      return true;
    } catch (error) {
      logger.error('Error deleting user:', error.message);
      throw error;
    }
  }

  // Hard delete user (admin only)
  static async hardDelete(id) {
    try {
      const [result] = await pool.execute(
        'DELETE FROM users WHERE id = ?',
        [id]
      );

      if (result.affectedRows === 0) {
        throw new Error('User not found');
      }

      return true;
    } catch (error) {
      logger.error('Error hard deleting user:', error.message);
      throw error;
    }
  }

  // Check if email exists
  static async emailExists(email, excludeId = null) {
    try {
      let query = 'SELECT COUNT(*) as count FROM users WHERE email = ?';
      let params = [email];

      if (excludeId) {
        query += ' AND id != ?';
        params.push(excludeId);
      }

      const [rows] = await pool.execute(query, params);
      return rows[0].count > 0;
    } catch (error) {
      logger.error('Error checking email existence:', error.message);
      throw error;
    }
  }

  // Get user statistics
  static async getStats() {
    try {
      const [rows] = await pool.execute(`
        SELECT 
          COUNT(*) as total_users,
          COUNT(CASE WHEN is_active = true THEN 1 END) as active_users,
          COUNT(CASE WHEN role = 'admin' THEN 1 END) as admin_users,
          COUNT(CASE WHEN role = 'leader' THEN 1 END) as leader_users,
          COUNT(CASE WHEN role = 'customer' THEN 1 END) as customer_users,
          COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as new_users_30d
        FROM users
      `);

      return rows[0];
    } catch (error) {
      logger.error('Error getting user stats:', error.message);
      throw error;
    }
  }

  // Search users
  static async search(searchTerm, options = {}) {
    try {
      const {
        page = 1,
        limit = 10,
        role,
        is_active
      } = options;

      let baseQuery = `
        SELECT id, full_name, email, phone, role, is_active, created_at, updated_at 
        FROM users 
        WHERE (full_name LIKE ? OR email LIKE ? OR phone LIKE ?)
      `;
      let params = [`%${searchTerm}%`, `%${searchTerm}%`, `%${searchTerm}%`];

      // Apply additional filters
      if (role) {
        baseQuery += ' AND role = ?';
        params.push(role);
      }

      if (is_active !== undefined) {
        baseQuery += ' AND is_active = ?';
        params.push(is_active);
      }

      // Add pagination
      const offset = (page - 1) * limit;
      baseQuery += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
      params.push(parseInt(limit), offset);

      const [rows] = await pool.execute(baseQuery, params);

      // Get total count
      let countQuery = `
        SELECT COUNT(*) as total 
        FROM users 
        WHERE (full_name LIKE ? OR email LIKE ? OR phone LIKE ?)
      `;
      let countParams = [`%${searchTerm}%`, `%${searchTerm}%`, `%${searchTerm}%`];

      if (role) {
        countQuery += ' AND role = ?';
        countParams.push(role);
      }

      if (is_active !== undefined) {
        countQuery += ' AND is_active = ?';
        countParams.push(is_active);
      }

      const [countResult] = await pool.execute(countQuery, countParams);

      return {
        users: rows,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: countResult[0].total,
          totalPages: Math.ceil(countResult[0].total / limit)
        }
      };
    } catch (error) {
      logger.error('Error searching users:', error.message);
      throw error;
    }
  }
}

module.exports = UserModel;
