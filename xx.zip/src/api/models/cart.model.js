
const { pool } = require('../../config/database');
const { v4: uuidv4 } = require('uuid');
const { logger } = require('../../utils/logger');

class CartModel {
  // Create a new cart
  static async create(cartData) {
    try {
      const { user_id, status = 'active' } = cartData;
      const id = uuidv4();
      const now = new Date();

      const [result] = await pool.execute(
        'INSERT INTO carts (id, user_id, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
        [id, user_id, status, now, now]
      );

      if (result.affectedRows === 0) {
        throw new Error('Failed to create cart');
      }

      return await this.findById(id);
    } catch (error) {
      logger.error('Error creating cart:', error.message);
      throw error;
    }
  }

  // Find active cart by user ID
  static async findActiveByUserId(userId) {
    try {
      const [rows] = await pool.execute(
        "SELECT * FROM carts WHERE user_id = ? AND status = 'active'",
        [userId]
      );
      return rows[0] || null;
    } catch (error) {
      logger.error('Error finding active cart by user ID:', error.message);
      throw error;
    }
  }

  // Find cart by ID
  static async findById(cartId) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM carts WHERE id = ?',
        [cartId]
      );
      return rows[0] || null;
    } catch (error) {
      logger.error('Error finding cart by ID:', error.message);
      throw error;
    }
  }

  // Update cart status
  static async updateStatus(cartId, status) {
    try {
      const [result] = await pool.execute(
        'UPDATE carts SET status = ?, updated_at = ? WHERE id = ?',
        [status, new Date(), cartId]
      );

      if (result.affectedRows === 0) {
        throw new Error('Cart not found or no changes made');
      }

      return true;
    } catch (error) {
      logger.error('Error updating cart status:', error.message);
      throw error;
    }
  }

  // Update cart
  static async update(cartId, updateData) {
    try {
      const fields = Object.keys(updateData);
      if (fields.length === 0) {
        throw new Error('No fields to update');
      }

      const setClause = fields.map(field => `${field} = ?`).join(', ');
      const values = [...Object.values(updateData), new Date(), cartId];

      const [result] = await pool.execute(
        `UPDATE carts SET ${setClause}, updated_at = ? WHERE id = ?`,
        values
      );

      if (result.affectedRows === 0) {
        throw new Error('Cart not found or no changes made');
      }

      return await this.findById(cartId);
    } catch (error) {
      logger.error('Error updating cart:', error.message);
      throw error;
    }
  }

  // Delete cart
  static async delete(cartId) {
    try {
      const [result] = await pool.execute(
        'DELETE FROM carts WHERE id = ?',
        [cartId]
      );

      if (result.affectedRows === 0) {
        throw new Error('Cart not found');
      }

      return true;
    } catch (error) {
      logger.error('Error deleting cart:', error.message);
      throw error;
    }
  }

  // Get all carts by user ID
  static async findByUserId(userId, options = {}) {
    try {
      const { status, page = 1, limit = 10 } = options;
      
      let whereClause = 'WHERE user_id = ?';
      let params = [userId];

      if (status) {
        whereClause += ' AND status = ?';
        params.push(status);
      }

      const offset = (page - 1) * limit;
      const [rows] = await pool.execute(
        `SELECT * FROM carts ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
        [...params, parseInt(limit), offset]
      );

      return rows;
    } catch (error) {
      logger.error('Error finding carts by user ID:', error.message);
      throw error;
    }
  }

  // Get cart statistics
  static async getStats(userId) {
    try {
      const [rows] = await pool.execute(`
        SELECT 
          COUNT(*) as total_carts,
          COUNT(CASE WHEN status = 'active' THEN 1 END) as active_carts,
          COUNT(CASE WHEN status = 'ordered' THEN 1 END) as ordered_carts,
          COUNT(CASE WHEN status = 'abandoned' THEN 1 END) as abandoned_carts,
          COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as new_carts_30d
        FROM carts 
        WHERE user_id = ?
      `, [userId]);

      return rows[0];
    } catch (error) {
      logger.error('Error getting cart stats:', error.message);
      throw error;
    }
  }

  // Clean up abandoned carts (older than specified days)
  static async cleanupAbandonedCarts(daysOld = 30) {
    try {
      const [result] = await pool.execute(
        `UPDATE carts 
         SET status = 'abandoned', updated_at = ? 
         WHERE status = 'active' 
         AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)`,
        [new Date(), daysOld]
      );

      logger.info(`Cleaned up ${result.affectedRows} abandoned carts`);
      return result.affectedRows;
    } catch (error) {
      logger.error('Error cleaning up abandoned carts:', error.message);
      throw error;
    }
  }

  // Get cart with items
  static async findByIdWithItems(cartId) {
    try {
      const cart = await this.findById(cartId);
      if (!cart) {
        return null;
      }

      // Get cart items
      const CartItemModel = require('./cartItem.model');
      const items = await CartItemModel.findByCartId(cartId);

      return {
        ...cart,
        items
      };
    } catch (error) {
      logger.error('Error finding cart with items:', error.message);
      throw error;
    }
  }

  // Check if user has active cart
  static async hasActiveCart(userId) {
    try {
      const cart = await this.findActiveByUserId(userId);
      return !!cart;
    } catch (error) {
      logger.error('Error checking if user has active cart:', error.message);
      throw error;
    }
  }

  // Get cart count by status
  static async getCountByStatus(userId) {
    try {
      const [rows] = await pool.execute(`
        SELECT status, COUNT(*) as count
        FROM carts 
        WHERE user_id = ?
        GROUP BY status
      `, [userId]);

      return rows.reduce((acc, row) => {
        acc[row.status] = row.count;
        return acc;
      }, {});
    } catch (error) {
      logger.error('Error getting cart count by status:', error.message);
      throw error;
    }
  }
}

module.exports = CartModel;
