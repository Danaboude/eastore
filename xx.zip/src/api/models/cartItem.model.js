
const { pool } = require('../../config/database');
const { v4: uuidv4 } = require('uuid');
const { logger } = require('../../utils/logger');

class CartItemModel {
  // Create a new cart item
  static async create(itemData) {
    try {
      const {
        cart_id,
        provider,
        product_url,
        quantity,
        title_snapshot,
        price_snapshot,
        currency,
        attributes,
        note = null
      } = itemData;

      const id = uuidv4();
      const now = new Date();

      const [result] = await pool.execute(
        `INSERT INTO cart_items (id, cart_id, provider, product_url, quantity, title_snapshot, price_snapshot, currency, note, attributes, created_at, updated_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        [id, cart_id, provider, product_url, quantity, title_snapshot, price_snapshot, currency, note, JSON.stringify(attributes), now, now]
      );

      if (result.affectedRows === 0) {
        throw new Error('Failed to create cart item');
      }

      return await this.findById(id);
    } catch (error) {
      logger.error('Error creating cart item:', error.message);
      throw error;
    }
  }

  // Find cart item by ID
  static async findById(itemId) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM cart_items WHERE id = ?',
        [itemId]
      );
      return rows[0] || null;
    } catch (error) {
      logger.error('Error finding cart item by ID:', error.message);
      throw error;
    }
  }

  // Find cart items by cart ID
  static async findByCartId(cartId) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM cart_items WHERE cart_id = ? ORDER BY created_at ASC',
        [cartId]
      );
      return rows;
    } catch (error) {
      logger.error('Error finding cart items by cart ID:', error.message);
      throw error;
    }
  }

  // Find cart item by cart and product
  static async findByCartAndProduct(cartId, provider, productUrl) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM cart_items WHERE cart_id = ? AND provider = ? AND product_url = ?',
        [cartId, provider, productUrl]
      );
      return rows[0] || null;
    } catch (error) {
      logger.error('Error finding cart item by cart and product:', error.message);
      throw error;
    }
  }

  // Update cart item
  static async update(itemId, updateData) {
    try {
      const fields = Object.keys(updateData);
      if (fields.length === 0) {
        throw new Error('No fields to update');
      }

      const setClause = fields.map(field => `${field} = ?`).join(', ');
      const values = [...Object.values(updateData), new Date(), itemId];

      // Handle attributes field specially (convert to JSON if it's an object)
      const processedValues = values.map((value, index) => {
        if (fields[index] === 'attributes' && typeof value === 'object') {
          return JSON.stringify(value);
        }
        return value;
      });

      const [result] = await pool.execute(
        `UPDATE cart_items SET ${setClause}, updated_at = ? WHERE id = ?`,
        processedValues
      );

      if (result.affectedRows === 0) {
        throw new Error('Cart item not found or no changes made');
      }

      return await this.findById(itemId);
    } catch (error) {
      logger.error('Error updating cart item:', error.message);
      throw error;
    }
  }

  // Update quantity
  static async updateQuantity(itemId, quantity) {
    try {
      if (quantity <= 0) {
        throw new Error('Quantity must be positive');
      }

      if (quantity > 9999) {
        throw new Error('Quantity cannot exceed 9999');
      }

      const [result] = await pool.execute(
        'UPDATE cart_items SET quantity = ?, updated_at = ? WHERE id = ?',
        [quantity, new Date(), itemId]
      );

      if (result.affectedRows === 0) {
        throw new Error('Cart item not found');
      }

      return await this.findById(itemId);
    } catch (error) {
      logger.error('Error updating cart item quantity:', error.message);
      throw error;
    }
  }

  // Delete cart item
  static async delete(itemId) {
    try {
      const [result] = await pool.execute(
        'DELETE FROM cart_items WHERE id = ?',
        [itemId]
      );

      if (result.affectedRows === 0) {
        throw new Error('Cart item not found');
      }

      return true;
    } catch (error) {
      logger.error('Error deleting cart item:', error.message);
      throw error;
    }
  }

  // Delete all items by cart ID
  static async deleteByCartId(cartId) {
    try {
      const [result] = await pool.execute(
        'DELETE FROM cart_items WHERE cart_id = ?',
        [cartId]
      );

      logger.info(`Deleted ${result.affectedRows} cart items for cart ${cartId}`);
      return result.affectedRows;
    } catch (error) {
      logger.error('Error deleting cart items by cart ID:', error.message);
      throw error;
    }
  }

  // Get cart item statistics
  static async getStats(cartId) {
    try {
      const [rows] = await pool.execute(`
        SELECT 
          COUNT(*) as total_items,
          SUM(quantity) as total_quantity,
          SUM(quantity * price_snapshot) as total_value,
          COUNT(DISTINCT provider) as provider_count,
          MIN(price_snapshot) as min_price,
          MAX(price_snapshot) as max_price,
          AVG(price_snapshot) as avg_price
        FROM cart_items 
        WHERE cart_id = ?
      `, [cartId]);

      return rows[0];
    } catch (error) {
      logger.error('Error getting cart item stats:', error.message);
      throw error;
    }
  }

  // Get items by provider
  static async findByProvider(cartId, provider) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM cart_items WHERE cart_id = ? AND provider = ? ORDER BY created_at ASC',
        [cartId, provider]
      );
      return rows;
    } catch (error) {
      logger.error('Error finding cart items by provider:', error.message);
      throw error;
    }
  }

  // Check if product exists in cart
  static async productExistsInCart(cartId, provider, productUrl) {
    try {
      const [rows] = await pool.execute(
        'SELECT COUNT(*) as count FROM cart_items WHERE cart_id = ? AND provider = ? AND product_url = ?',
        [cartId, provider, productUrl]
      );
      return rows[0].count > 0;
    } catch (error) {
      logger.error('Error checking if product exists in cart:', error.message);
      throw error;
    }
  }

  // Get cart items with product details
  static async findWithProductDetails(cartId) {
    try {
      const [rows] = await pool.execute(`
        SELECT 
          ci.*,
          c.user_id,
          c.status as cart_status
        FROM cart_items ci
        JOIN carts c ON ci.cart_id = c.id
        WHERE ci.cart_id = ?
        ORDER BY ci.created_at ASC
      `, [cartId]);

      return rows;
    } catch (error) {
      logger.error('Error finding cart items with product details:', error.message);
      throw error;
    }
  }

  // Bulk update cart items
  static async bulkUpdate(cartId, updates) {
    try {
      const connection = await pool.getConnection();
      
      try {
        await connection.beginTransaction();

        for (const update of updates) {
          const { itemId, ...updateData } = update;
          await this.update(itemId, updateData);
        }

        await connection.commit();
        return true;
      } catch (error) {
        await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }
    } catch (error) {
      logger.error('Error bulk updating cart items:', error.message);
      throw error;
    }
  }

  // Validate cart item data
  static validateItemData(itemData) {
    const errors = [];

    if (!itemData.cart_id) errors.push('Cart ID is required');
    if (!itemData.provider) errors.push('Provider is required');
    if (!itemData.product_url) errors.push('Product URL is required');
    if (!itemData.quantity || itemData.quantity < 1) errors.push('Valid quantity is required');
    if (itemData.quantity > 9999) errors.push('Quantity cannot exceed 9999');
    if (!itemData.attributes) errors.push('Attributes are required');

    return errors;
  }
}

module.exports = CartItemModel;
