const { pool } = require('../../config/database');
const { logger } = require('../../utils/logger');
const { v4: uuidv4 } = require('uuid');

class ServiceAnswerModel {
  /**
   * Create multiple answers for a service request
   * @param {string} serviceRequestId - The ID of the service request
   * @param {Array} answers - An array of answer objects, each with question_id and answer_text
   * @returns {Promise<boolean>} - A promise that resolves to true if successful
   */
  static async createMany(serviceRequestId, answers) {
    if (!answers || answers.length === 0) {
      return true;
    }

    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const query = 'INSERT INTO service_answers (id, service_request_id, question_id, answer_text) VALUES ?';
      const values = answers.map(answer => [
        uuidv4(),
        serviceRequestId,
        answer.question_id,
        answer.answer_text
      ]);

      await connection.query(query, [values]);
      await connection.commit();
      
      return true;
    } catch (error) {
      await connection.rollback();
      logger.error(`Error creating service answers for request ${serviceRequestId}:`, error.message);
      throw error;
    } finally {
      connection.release();
    }
  }

  static async findByServiceRequestId(serviceRequestId) {
    try {
      const [rows] = await pool.execute(
        `SELECT sa.answer_text, sq.question_text, sq.question_type, sq.sort_order
         FROM service_answers sa
         JOIN service_questions sq ON sa.question_id = sq.id
         WHERE sa.service_request_id = ?
         ORDER BY sq.sort_order ASC`,
        [serviceRequestId]
      );
      return rows;
    } catch (error) {
      logger.error(`Error finding service answers for request ${serviceRequestId}:`, error.message);
      throw error;
    }
  }
}

module.exports = ServiceAnswerModel;
