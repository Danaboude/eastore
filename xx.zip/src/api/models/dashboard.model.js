const { pool } = require('../../config/database');

class DashboardModel {
  static async getStats() {
    const [revenueResult, ordersResult, usersResult, dailyRevenueResult] = await Promise.all([
      pool.execute("SELECT SUM(total) as totalRevenue FROM orders WHERE status IN ('paid', 'fulfilled')"),
      pool.execute("SELECT COUNT(*) as totalOrders, SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pendingOrders FROM orders"),
      pool.execute("SELECT COUNT(*) as totalUsers FROM users WHERE role = 'customer'"),
      pool.execute(`
        SELECT DATE(created_at) as date, SUM(total) as dailyTotal
        FROM orders
        WHERE status IN ('paid', 'fulfilled') AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at) ASC
      `)
    ]);

    const revenue = revenueResult[0];
    const orders = ordersResult[0];
    const users = usersResult[0];
    const dailyRevenue = dailyRevenueResult[0];

    return {
      totalRevenue: revenue[0].totalRevenue || 0,
      totalOrders: orders[0].totalOrders || 0,
      pendingOrders: orders[0].pendingOrders || 0,
      totalUsers: users[0].totalUsers || 0,
      dailyRevenue: dailyRevenue,
    };
  }
}

module.exports = DashboardModel;
