const { pool } = require('../../config/database');
const { logger } = require('../../utils/logger');

class ServiceQuestionModel {
  /**
   * Find questions by category
   * @param {string} category - The category of questions to fetch ('app', 'website', 'other')
   * @returns {Promise<Array>} - A promise that resolves to an array of questions
   */
  static async findByCategory(category) {
    try {
      const [rows] = await pool.execute(
        'SELECT id, category, question_text, question_type, options, price_data, sort_order FROM service_questions WHERE category = ? ORDER BY sort_order ASC',
        [category]
      );
      return rows;
    } catch (error) {
      logger.error(`Error fetching service questions for category ${category}:`, error.message);
      throw error;
    }
  }
}

module.exports = ServiceQuestionModel;
