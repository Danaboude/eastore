const { pool } = require('../../config/database');
const { logger } = require('../../utils/logger');

class OrderItemModel {
  static async getItemsByOrderId(orderId) {
    try {
      const [rows] = await pool.execute('SELECT * FROM order_items WHERE order_id = ?', [orderId]);
      return rows;
    } catch (error) {
      logger.error('Error getting order items by order ID:', error.message);
      throw error;
    }
  }

  static async findById(itemId) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM order_items WHERE id = ?',
        [itemId]
      );
      return rows[0] || null;
    } catch (error) {
      logger.error('Error finding order item by ID:', error.message);
      throw error;
    }
  }

  static async update(itemId, updateData) {
    try {
      const fields = Object.keys(updateData);
      if (fields.length === 0) {
        throw new Error('No fields to update');
      }

      const setClause = fields.map(field => `${field} = ?`).join(', ');
      const values = [...Object.values(updateData), itemId];

      const [result] = await pool.execute(
        `UPDATE order_items SET ${setClause} WHERE id = ?`,
        values
      );

      if (result.affectedRows === 0) {
        throw new Error('Order item not found or no changes made');
      }

      return await this.findById(itemId);
    } catch (error) {
      logger.error('Error updating order item:', error.message);
      throw error;
    }
  }
}

module.exports = OrderItemModel;