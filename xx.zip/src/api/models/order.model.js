
const { pool } = require('../../config/database');
const { v4: uuidv4 } = require('uuid');
const CartModel = require('./cart.model'); // Import CartModel

class OrderModel {
  static async createFromCart(
    userId,
    cartId,
    subtotal,
    shipping,
    tax,
    total,
    currency,
    payment_type, 
    shipping_address_line1, 
    shipping_city, 
    phone_number, 
    name 
  ) {
    const connection = await pool.getConnection();
    await connection.beginTransaction();

    try {
      // Create the order
      const orderId = uuidv4();
      await connection.execute(
        `INSERT INTO orders (
          id, user_id, cart_id, status, subtotal, shipping, tax, total, currency,
          payment_type, shipping_address_line1, shipping_city, phone_number, name
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        [
          orderId,
          userId,
          cartId,
          'pending', 
          subtotal,
          shipping,
          tax,
          total,
          currency,
          payment_type,
          shipping_address_line1,
          shipping_city,
          phone_number,
          name
        ]
      );

      // Move cart items to order items
      await connection.execute(`
        INSERT INTO order_items (id, order_id, provider, product_url, quantity, title_snapshot, price_snapshot, currency, attributes)
        SELECT UUID(), ?, provider, product_url, quantity, title_snapshot, price_snapshot, currency, attributes
        FROM cart_items WHERE cart_id = ?
      `, [orderId, cartId]);

      // Update cart status to 'ordered'
      await connection.execute("UPDATE carts SET status = 'ordered' WHERE id = ?", [cartId]);

      // Create a new active cart for the user
      await CartModel.create({ user_id: userId, status: 'active' }); 

      await connection.commit();
      return { id: orderId };

    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  }

  static async findByUserId(userId) {
    const [rows] = await pool.execute('SELECT *, payment_type, shipping_address_line1, shipping_city, phone_number, name FROM orders WHERE user_id = ? ORDER BY created_at DESC', [userId]);
    return rows;
  }

  static async findById(orderId) {
    const [rows] = await pool.execute('SELECT *, payment_type, shipping_address_line1, shipping_city, phone_number, name FROM orders WHERE id = ?', [orderId]);
    return rows[0];
  }

  static async findAll(options = {}) {
    const {
      page = 1,
      limit = 10,
      search,
      status,
      sort_by = 'created_at',
      sort_order = 'desc'
    } = options;

    let baseQuery = 'SELECT o.*, u.full_name as user_name, u.email as user_email, o.payment_type, o.shipping_address_line1, o.shipping_city, o.phone_number, o.name FROM orders o LEFT JOIN users u ON o.user_id = u.id';
    let countQuery = 'SELECT COUNT(*) as total FROM orders o LEFT JOIN users u ON o.user_id = u.id';
    
    let whereClauses = [];
    let queryParams = [];

    if (search) {
      whereClauses.push('(o.id LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)');
      queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    if (status) {
      whereClauses.push('o.status = ?');
      queryParams.push(status);
    }

    if (whereClauses.length > 0) {
      const whereString = ' WHERE ' + whereClauses.join(' AND ');
      baseQuery += whereString;
      countQuery += whereString;
    }

    const [countResult] = await pool.execute(countQuery, queryParams);
    const total = countResult[0].total;

    const offset = (page - 1) * limit;
    baseQuery += ` ORDER BY ${sort_by} ${sort_order.toUpperCase()} LIMIT ? OFFSET ?`;
    queryParams.push(parseInt(limit), offset);

    const [rows] = await pool.execute(baseQuery, queryParams);

    return {
      orders: rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: total,
        totalPages: Math.ceil(total / limit)
      }
    };
  }

  static async updateStatus(orderId, status) {
    const [result] = await pool.execute(
      'UPDATE orders SET status = ? WHERE id = ?',
      [status, orderId]
    );
    return result.affectedRows > 0;
  }

  static async update(orderId, updateData) {
    const fields = Object.keys(updateData);
    if (fields.length === 0) {
        return await this.findById(orderId);
    }
    const setClause = fields.map(field => `${field} = ?`).join(', ');
    const values = [...Object.values(updateData), new Date(), orderId];

    const [result] = await pool.execute(
        `UPDATE orders SET ${setClause}, updated_at = ? WHERE id = ?`,
        values
    );

    if (result.affectedRows === 0) {
        throw new Error('Order not found or no changes made');
    }
    return await this.findById(orderId);
  }

  static async updateTotals(orderId, subtotal, total) {
    const [result] = await pool.execute(
      'UPDATE orders SET subtotal = ?, total = ?, updated_at = ? WHERE id = ?',
      [subtotal, total, new Date(), orderId]
    );
    return result.affectedRows > 0;
  }
}


module.exports = OrderModel;
