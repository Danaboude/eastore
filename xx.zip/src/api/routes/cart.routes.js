
const express = require('express');
const router = express.Router();
const CartController = require('../controllers/cart.controller');
const { authenticate } = require('../../middleware/auth.middleware');
const { validate, schemas } = require('../../middleware/validation.middleware');

// All cart routes require authentication
router.use(authenticate);

// @route   GET api/cart
// @desc    Get user's active cart
// @access  Private
router.get('/', CartController.getCart);

// @route   GET api/cart/summary
// @desc    Get cart summary
// @access  Private
router.get('/summary', CartController.getCartSummary);

// @route   GET api/cart/history
// @desc    Get cart history
// @access  Private
router.get('/history', CartController.getCartHistory);

// @route   POST api/cart/items
// @desc    Add item to cart
// @access  Private
router.post('/items', 
  validate(schemas.cartItem), 
  CartController.addItem
);

// @route   PUT api/cart/items/:itemId
// @desc    Update cart item
// @access  Private
router.put('/items/:itemId', 
  validate(schemas.cartItem), 
  CartController.updateItem
);

// @route   DELETE api/cart/items/:itemId
// @desc    Remove item from cart
// @access  Private
router.delete('/items/:itemId', CartController.removeItem);

// @route   DELETE api/cart
// @desc    Clear cart
// @access  Private
router.delete('/', CartController.clearCart);

module.exports = router;
