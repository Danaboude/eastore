
const express = require('express');
const router = express.Router();
const OrderController = require('../controllers/order.controller');
const { authenticate } = require('../../middleware/auth.middleware');
const { requireAdmin, requireLeader } = require('../../middleware/role.middleware'); // Import requireLeader
const { validate, schemas } = require('../../middleware/validation.middleware'); // Import validate and schemas
const Joi = require('joi'); // Import Joi for inline schema definition

// All order routes are protected
router.use(authenticate);

// @route   POST api/orders
// @desc    Create a new order from the user's cart
// @access  Private
router.post('/', OrderController.createOrder);

// @route   GET api/orders
// @desc    Get a list of the user's orders
// @access  Private
router.get('/', OrderController.getOrders);

// Admin routes
router.get('/all', authenticate, requireAdmin, OrderController.getAllOrders);

// @route   GET api/orders/:orderId
// @desc    Get the details of a specific order
// @access  Private
router.get('/:orderId', OrderController.getOrderDetails);

router.put('/:orderId/status', authenticate, requireAdmin, OrderController.updateOrderStatus);

// @route   PUT api/orders/:orderId/items
// @desc    Update order items
// @access  Private (Admin/Leader)
router.put('/:orderId/items', 
  authenticate, 
  requireLeader, // Admin or Leader can update
  validate(Joi.object({
    items: Joi.array().items(schemas.orderItemUpdate).min(1),
    shipping_address_line1: Joi.string().max(255).optional(),
    shipping_city: Joi.string().max(255).optional(),
    phone_number: Joi.string().pattern(/^[+]?[\d\s\-\(\)]+$/).optional()
  }).or('items', 'shipping_address_line1', 'shipping_city', 'phone_number')),
  OrderController.updateOrderItems
);

module.exports = router;
