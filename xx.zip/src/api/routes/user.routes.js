
const express = require('express');
const router = express.Router();
const UserController = require('../controllers/user.controller');
const { authenticate, optionalAuth } = require('../../middleware/auth.middleware');
const { 
  requireAdmin, 
  requireLeader, 
  canAccessResource 
} = require('../../middleware/role.middleware');
const { validate, schemas } = require('../../middleware/validation.middleware');

// Public routes
// @route   POST api/users/register
// @desc    Register a new user
// @access  Public
router.post('/register', 
  validate(schemas.userRegistration), 
  UserController.register
);

// @route   POST api/users/login
// @desc    Authenticate user & get token
// @access  Public
router.post('/login', 
  validate(schemas.userLogin), 
  UserController.login
);

// @route   POST api/users/refresh-token
// @desc    Refresh access token
// @access  Public
router.post('/refresh-token', UserController.refreshToken);

// Protected routes (require authentication)
// @route   GET api/users/profile
// @desc    Get current user profile
// @access  Private
router.get('/profile', authenticate, UserController.getProfile);

// @route   PUT api/users/profile
// @desc    Update current user profile
// @access  Private
router.put('/profile', 
  authenticate, 
  validate(schemas.userUpdate), 
  UserController.updateProfile
);

// @route   PUT api/users/change-password
// @desc    Change user password
// @access  Private
router.put('/change-password', 
  authenticate, 
  UserController.changePassword
);

// @route   POST api/users/logout
// @desc    Logout user
// @access  Private
router.post('/logout', authenticate, UserController.logout);

// @route   POST api/users/fcm-token
// @desc    Update user's FCM token
// @access  Private
router.post('/fcm-token', authenticate, UserController.updateFcmToken);

// Admin/Leader routes
// @route   GET api/users
// @desc    Get all users (with pagination and filters)
// @access  Private (Admin/Leader)
router.get('/', 
  authenticate, 
  requireLeader, 
  UserController.getAllUsers
);

// @route   GET api/users/:id
// @desc    Get user by ID
// @access  Private (Admin/Leader)
router.get('/:id', 
  authenticate, 
  requireLeader, 
  UserController.getUserById
);

// @route   PUT api/users/:id
// @desc    Update user by ID
// @access  Private (Admin/Leader)
router.put('/:id', 
  authenticate, 
  requireLeader, 
  validate(schemas.userUpdate), 
  UserController.updateUserById
);

// @route   DELETE api/users/:id
// @desc    Delete user (soft delete)
// @access  Private (Admin only)
router.delete('/:id', 
  authenticate, 
  requireAdmin, 
  UserController.deleteUser
);

module.exports = router;
