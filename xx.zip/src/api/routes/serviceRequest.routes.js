
const express = require('express');
const router = express.Router();
const ServiceRequestController = require('../controllers/serviceRequest.controller');
const { authenticate } = require('../../middleware/auth.middleware');
const { requireLeader } = require('../../middleware/role.middleware');

// All service request routes are protected
router.use(authenticate);

// @route   GET api/requests/questions/:category
// @desc    Get service questions for a category
// @access  Private (Customer)
router.get('/questions/:category', ServiceRequestController.getQuestions);

router.post('/calculate-price', ServiceRequestController.calculatePrice);

// POST a new service request
router.post('/', ServiceRequestController.createRequest);

// @route   GET api/requests
// @desc    Get a list of the user's service requests
// @access  Private (Customer)
router.get('/', ServiceRequestController.getRequests);

// @route   GET api/requests/all
// @desc    Get all service requests
// @access  Private (Admin, Leader)
router.get('/all', requireLeader, ServiceRequestController.getAllServiceRequests);

// @route   GET api/requests/:requestId
// @desc    Get the details of a specific service request
// @access  Private (Customer)
router.get('/:requestId', ServiceRequestController.getRequestDetails);

// @route   PUT api/requests/:requestId/status
// @desc    Update the status of a service request
// @access  Private (Admin, Leader)
router.put('/:requestId/status', requireLeader, ServiceRequestController.updateRequestStatus);

module.exports = router;
