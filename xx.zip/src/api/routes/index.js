
const express = require('express');
const router = express.Router();

const userRoutes = require('./user.routes');
const cartRoutes = require('./cart.routes');
const orderRoutes = require('./order.routes');
const serviceRequestRoutes = require('./serviceRequest.routes');
const dashboardRoutes = require('./dashboard.routes');


// API Documentation
router.get('/docs', (req, res) => {
  res.json({
    message: 'EA Store API Documentation',
    version: '1.0.0',
    endpoints: {
      users: '/api/users',
      cart: '/api/cart',
      orders: '/api/orders',
      serviceRequests: '/api/requests'
    },
    documentation: 'https://github.com/your-repo/eastore#api-documentation'
  });
});

// Health check for API routes
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    service: 'EA Store API',
    timestamp: new Date().toISOString()
  });
});

// Route definitions
router.use('/users', userRoutes);
router.use('/cart', cartRoutes);
router.use('/orders', orderRoutes);
router.use('/requests', serviceRequestRoutes);
router.use('/dashboard', dashboardRoutes);

module.exports = router;
s = router;
