
const UserModel = require('../models/user.model');
const FcmTokenModel = require('../models/fcmToken.model');
const bcrypt = require('bcryptjs');
const { generateToken, generateRefreshToken } = require('../../middleware/auth.middleware');
const { AppError } = require('../../middleware/error.middleware');
const { logger } = require('../../utils/logger');
const { executeQuery, executeQueryOne, getPaginatedResults } = require('../../utils/database');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');

class UserController {
  // User registration
  static async register(req, res, next) {
    try {
      const { full_name, email, password, phone, role = 'customer' } = req.body;

      // Check if user already exists
      const existingUser = await UserModel.findByEmail(email);
      if (existingUser) {
        throw new AppError('Email already in use', 409);
      }

      // Hash password
      const saltRounds = parseInt(process.env.BCRYPT_ROUNDS) || 12;
      const passwordHash = await bcrypt.hash(password, saltRounds);

      // Create user
      const newUser = await UserModel.create({
        full_name,
        email,
        phone,
        password_hash: passwordHash,
        password_algo: 'bcrypt',
        role
      });

      // Generate tokens
      const accessToken = generateToken(newUser);
      const refreshToken = generateRefreshToken(newUser);

      // Log successful registration
      logger.info('User registered successfully', { userId: newUser.id, email });

      res.status(201).json({
        success: true,
        message: 'User registered successfully',
        data: {
          user: {
            id: newUser.id,
            full_name: newUser.full_name,
            email: newUser.email,
            phone: newUser.phone,
            role: newUser.role,
            is_active: newUser.is_active
          },
          tokens: {
            access_token: accessToken,
            refresh_token: refreshToken
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // User login
  static async login(req, res, next) {
    try {
      const { email, password } = req.body;

      // Find user by email
      const user = await UserModel.findByEmail(email);
      if (!user) {
        throw new AppError('Invalid credentials', 401);
      }

      // Check if user is active
      if (!user.is_active) {
        throw new AppError('Account is deactivated. Please contact support.', 401);
      }

      // Verify password
      const isMatch = await bcrypt.compare(password, user.password_hash);
      if (!isMatch) {
        throw new AppError('Invalid credentials', 401);
      }

      // Generate tokens
      const accessToken = generateToken(user);
      const refreshToken = generateRefreshToken(user);

      // Update last login (optional)
      await UserModel.updateLastLogin(user.id);

      // Log successful login
      logger.info('User logged in successfully', { userId: user.id, email });

      res.json({
        success: true,
        message: 'Login successful',
        data: {
          user: {
            id: user.id,
            full_name: user.full_name,
            email: user.email,
            phone: user.phone,
            role: user.role,
            is_active: user.is_active
          },
          tokens: {
            access_token: accessToken,
            refresh_token: refreshToken
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Refresh token
  static async refreshToken(req, res, next) {
    try {
      const { refresh_token } = req.body;

      if (!refresh_token) {
        throw new AppError('Refresh token is required', 400);
      }

      // Verify refresh token
      const decoded = jwt.verify(refresh_token, process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET);
      
      // Get user
      const user = await UserModel.findById(decoded.user.id);
      if (!user || !user.is_active) {
        throw new AppError('Invalid refresh token', 401);
      }

      // Generate new tokens
      const newAccessToken = generateToken(user);
      const newRefreshToken = generateRefreshToken(user);

      res.json({
        success: true,
        message: 'Token refreshed successfully',
        data: {
          tokens: {
            access_token: newAccessToken,
            refresh_token: newRefreshToken
          }
        }
      });
    } catch (error) {
      if (error.name === 'JsonWebTokenError') {
        next(new AppError('Invalid refresh token', 401));
      } else if (error.name === 'TokenExpiredError') {
        next(new AppError('Refresh token expired', 401));
      } else {
        next(error);
      }
    }
  }

  // Get current user profile
  static async getProfile(req, res, next) {
    try {
      const userId = req.user.id;
      const user = await UserModel.findById(userId);

      if (!user) {
        throw new AppError('User not found', 404);
      }

      res.json({
        success: true,
        data: {
          user: {
            id: user.id,
            full_name: user.full_name,
            email: user.email,
            phone: user.phone,
            role: user.role,
            is_active: user.is_active,
            created_at: user.created_at,
            updated_at: user.updated_at
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Update user profile
  static async updateProfile(req, res, next) {
    try {
      const userId = req.user.id;
      const { full_name, phone, password } = req.body;

      // Check if user exists
      const existingUser = await UserModel.findById(userId);
      if (!existingUser) {
        throw new AppError('User not found', 404);
      }

      // Prepare update data
      const updateData = {};
      if (full_name) updateData.full_name = full_name;
      if (phone) updateData.phone = phone;
      if (password) {
        const saltRounds = parseInt(process.env.BCRYPT_ROUNDS) || 12;
        updateData.password_hash = await bcrypt.hash(password, saltRounds);
        updateData.password_algo = 'bcrypt';
      }

      // Update user
      const updatedUser = await UserModel.update(userId, updateData);

      logger.info('User profile updated', { userId, updatedFields: Object.keys(updateData) });

      res.json({
        success: true,
        message: 'Profile updated successfully',
        data: {
          user: {
            id: updatedUser.id,
            full_name: updatedUser.full_name,
            email: updatedUser.email,
            phone: updatedUser.phone,
            role: updatedUser.role,
            is_active: updatedUser.is_active,
            updated_at: updatedUser.updated_at
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Get all users (admin/leader only)
  static async getAllUsers(req, res, next) {
    try {
      const { page = 1, limit = 10, search, role, is_active } = req.query;
      const results = await UserModel.findAll({ page, limit, search, role, is_active });

      res.json({
        success: true,
        data: results.users,
        pagination: results.pagination
      });
    } catch (error) {
      next(error);
    }
  }

  // Get user by ID (admin/leader only)
  static async getUserById(req, res, next) {
    try {
      const { id } = req.params;
      const user = await UserModel.findById(id);

      if (!user) {
        throw new AppError('User not found', 404);
      }

      res.json({
        success: true,
        data: {
          user: {
            id: user.id,
            full_name: user.full_name,
            email: user.email,
            phone: user.phone,
            role: user.role,
            is_active: user.is_active,
            created_at: user.created_at,
            updated_at: user.updated_at
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Update user by ID (admin/leader only)
  static async updateUserById(req, res, next) {
    try {
      const { id } = req.params;
      const { full_name, email, phone, role, is_active, password } = req.body;

      // Check if user exists
      const existingUser = await UserModel.findById(id);
      if (!existingUser) {
        throw new AppError('User not found', 404);
      }

      // Prepare update data
      const updateData = {};
      if (full_name !== undefined) updateData.full_name = full_name;
      if (email !== undefined) updateData.email = email;
      if (phone !== undefined) updateData.phone = phone;
      if (role !== undefined) updateData.role = role;
      if (is_active !== undefined) updateData.is_active = is_active;
      if (password) {
        const saltRounds = parseInt(process.env.BCRYPT_ROUNDS) || 12;
        updateData.password_hash = await bcrypt.hash(password, saltRounds);
        updateData.password_algo = 'bcrypt';
      }

      // Update user
      const updatedUser = await UserModel.update(id, updateData);

      logger.info('User updated by admin', { userId: id, updatedBy: req.user.id, updatedFields: Object.keys(updateData) });

      res.json({
        success: true,
        message: 'User updated successfully',
        data: {
          user: {
            id: updatedUser.id,
            full_name: updatedUser.full_name,
            email: updatedUser.email,
            phone: updatedUser.phone,
            role: updatedUser.role,
            is_active: updatedUser.is_active,
            updated_at: updatedUser.updated_at
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Delete user (admin only)
  static async deleteUser(req, res, next) {
    try {
      const { id } = req.params;

      // Check if user exists
      const existingUser = await UserModel.findById(id);
      if (!existingUser) {
        throw new AppError('User not found', 404);
      }

      // Prevent self-deletion
      if (id === req.user.id) {
        throw new AppError('Cannot delete your own account', 400);
      }

      // Soft delete (deactivate user)
      await UserModel.update(id, { is_active: false });

      logger.info('User deactivated', { userId: id, deactivatedBy: req.user.id });

      res.json({
        success: true,
        message: 'User deactivated successfully'
      });
    } catch (error) {
      next(error);
    }
  }

  // Change password
  static async changePassword(req, res, next) {
    try {
      const userId = req.user.id;
      const { currentPassword, newPassword } = req.body;

      // Get user with password
      const user = await UserModel.findByIdWithPassword(userId);
      if (!user) {
        throw new AppError('User not found', 404);
      }

      // Verify current password
      const isMatch = await bcrypt.compare(currentPassword, user.password_hash);
      if (!isMatch) {
        throw new AppError('Current password is incorrect', 400);
      }

      // Hash new password
      const saltRounds = parseInt(process.env.BCRYPT_ROUNDS) || 12;
      const newPasswordHash = await bcrypt.hash(newPassword, saltRounds);

      // Update password
      await UserModel.update(userId, {
        password_hash: newPasswordHash,
        password_algo: 'bcrypt'
      });

      logger.info('User password changed', { userId });

      res.json({
        success: true,
        message: 'Password changed successfully'
      });
    } catch (error) {
      next(error);
    }
  }

  static async updateFcmToken(req, res, next) {
    try {
      const userId = req.user.id;
      const { token } = req.body;

      if (!token) {
        throw new AppError('FCM token is required', 400);
      }

      await FcmTokenModel.createOrUpdate(userId, token);

      res.json({
        success: true,
        message: 'FCM token updated successfully'
      });
    } catch (error) {
      next(error);
    }
  }

  // Logout (optional - for token blacklisting in future)
  static async logout(req, res, next) {
    try {
      // In a real application, you might want to blacklist the token
      // For now, just return success
      logger.info('User logged out', { userId: req.user.id });

      res.json({
        success: true,
        message: 'Logged out successfully'
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = UserController;
