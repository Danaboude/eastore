
const ServiceRequestModel = require('../models/serviceRequest.model');
const ServiceQuestionModel = require('../models/serviceQuestion.model');
const ServiceAnswerModel = require('../models/serviceAnswer.model');
const { AppError } = require('../../middleware/error.middleware');
const { calculateEstimatedPrice } = require('../../services/priceCalculator.service');
const NotificationService = require('../../services/notification.service');
const { logger } = require('../../utils/logger');

class ServiceRequestController {
  static async calculatePrice(req, res, next) {
    const { category, answers } = req.body;
    try {
      const estimatedPrice = await calculateEstimatedPrice(category, answers);
      res.json({
        success: true,
        data: {
          estimated_price: estimatedPrice,
          currency: 'USD', // Or make it dynamic if needed
        },
      });
    } catch (error) {
      next(error);
    }
  }

  static async createRequest(req, res, next) {
    const userId = req.user.id;
    const { category, note = null, answers } = req.body;
    const currency = 'USD';

    if (!category) {
      return next(new AppError('Category is required', 400));
    }

    try {
      const estimatedPrice = await calculateEstimatedPrice(category, answers);

      const newRequest = await ServiceRequestModel.create(
        userId,
        category,
        note,
        estimatedPrice,
        currency
      );

      if (answers && Array.isArray(answers) && answers.length > 0) {
        await ServiceAnswerModel.createMany(newRequest.id, answers);
      }

      // Refetch the request to include all fields for the response
      const finalRequest = await ServiceRequestModel.findById(newRequest.id);

      // Send notification to admins and leaders
      try {
        await NotificationService.sendToAdminsAndLeaders({
          title: 'طلب خدمة جديد',
          body: `تم إنشاء طلب خدمة جديد من قبل ${req.user.full_name || 'عميل'}. رقم الطلب: ${newRequest.id.substring(0, 8)}`
        }, { requestId: newRequest.id, type: 'new_service_request' });
      } catch (notificationError) {
        logger.error('Failed to send notification for new service request:', notificationError);
      }

      res.status(201).json({
        message: 'Service request created',
        request: finalRequest, // Send the full request object back
      });
    } catch (error) {
      next(error);
    }
  }

  static async getQuestions(req, res, next) {
    const { category } = req.params;
    if (!['app', 'website', 'other'].includes(category)) {
      return next(new AppError('Invalid category', 400));
    }

    try {
      const questions = await ServiceQuestionModel.findByCategory(category);
      res.json({ success: true, data: questions });
    } catch (error) {
      next(error);
    }
  }

  static async getRequests(req, res, next) {
    const userId = req.user.id;
    try {
      const requests = await ServiceRequestModel.findByUserId(userId);
      res.json(requests);
    } catch (error) {
      next(error);
    }
  }

  static async getRequestDetails(req, res, next) {
    const { requestId } = req.params;
    const userId = req.user.id;

    try {
      const request = await ServiceRequestModel.findById(requestId);

      if (!request) {
        return next(new AppError('Service request not found', 404));
      }

      // Allow admin/leader to see any request, but customers only their own.
      if (req.user.role === 'customer' && request.user_id !== userId) {
        return next(new AppError('Service request not found', 404));
      }

      const answers = await ServiceAnswerModel.findByServiceRequestId(requestId);

      res.json({ ...request, answers });
    } catch (error) {
      next(error);
    }
  }

  static async updateRequestStatus(req, res, next) {
    const { requestId } = req.params;
    const { status } = req.body;

    if (!status) {
      return next(new AppError('Status is required', 400));
    }

    try {
      const updated = await ServiceRequestModel.updateStatus(requestId, status);
      if (!updated) {
        return next(new AppError('Service request not found', 404));
      }

      // Get the request to find the user
      const request = await ServiceRequestModel.findById(requestId);
      if (request && request.user_id) {
        // Send notification to the customer
        try {
          await NotificationService.sendToUser(request.user_id, {
            title: 'تحديث حالة طلب الخدمة',
            body: `تم تحديث حالة طلب الخدمة رقم ${requestId.substring(0, 8)} إلى: ${status}`
          }, { requestId: requestId, type: 'service_request_status_update' });
        } catch (notificationError) {
          logger.error('Failed to send notification for service request status update:', notificationError);
        }
      }

      res.json({ message: 'Service request status updated' });
    } catch (error) {
      next(error);
    }
  }

  static async getAllServiceRequests(req, res, next) {
    try {
      const { page = 1, limit = 10, search, status } = req.query;
      const results = await ServiceRequestModel.findAll({ page, limit, search, status });
      res.json({
        success: true,
        data: results.requests,
        pagination: results.pagination
      });
    } catch (error) {
      next(error);
    }
  }
}




module.exports = ServiceRequestController;
