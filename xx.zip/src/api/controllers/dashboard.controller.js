const DashboardModel = require('../models/dashboard.model');

class DashboardController {
  static async getStats(req, res, next) {
    try {
      const stats = await DashboardModel.getStats();
      res.json({ success: true, data: stats });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = DashboardController;
