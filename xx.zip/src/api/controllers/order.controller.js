
const OrderModel = require('../models/order.model');
const OrderItemModel = require('../models/orderItem.model');
const CartModel = require('../models/cart.model');
const CartItemModel = require('../models/cartItem.model');
const { AppError } = require('../../middleware/error.middleware');
const { logger } = require('../../utils/logger');
const NotificationService = require('../../services/notification.service');

class OrderController {
  static async createOrder(req, res, next) {
    const userId = req.user.id;
    const { 
      currency = 'AED', 
      payment_type,
      shipping_address_line1,
      shipping_city,
      phone_number,
      name
    } = req.body; 

    try {
      const cart = await CartModel.findActiveByUserId(userId);
      if (!cart) {
        return res.status(404).json({ message: 'No active cart found' });
      }

      const cartItems = await CartItemModel.findByCartId(cart.id);
      if (cartItems.length === 0) {
        return res.status(400).json({ message: 'Cannot create an order with an empty cart' });
      }

      const subtotal = cartItems.reduce((sum, item) => sum + (item.price_snapshot * item.quantity), 0);
      const shipping = 0; 
      const tax = 0;      
      const total = subtotal + shipping + tax;

      const newOrder = await OrderModel.createFromCart(
        userId, 
        cart.id, 
        subtotal, 
        shipping, 
        tax, 
        total, 
        currency,
        payment_type, 
        shipping_address_line1, 
        shipping_city, 
        phone_number, 
        name 
      );

      // Send notification to admins and leaders
      try {
        await NotificationService.sendToAdminsAndLeaders({
          title: 'طلب جديد',
          body: `تم إنشاء طلب جديد من قبل ${req.user.full_name || 'عميل'}. رقم الطلب: ${newOrder.id.substring(0, 8)}`
        }, { orderId: newOrder.id, type: 'new_order' });
      } catch (notificationError) {
        logger.error('Failed to send notification for new order:', notificationError);
      }

      res.status(201).json({ message: 'Order created successfully', order: newOrder });
    } catch (error) {
      next(error);
    }
  }

  static async getOrders(req, res, next) {
    const userId = req.user.id;
    try {
      const orders = await OrderModel.findByUserId(userId);
      res.json({
        success: true,
        data: orders
      });
    } catch (error) {
      next(error);
    }
  }

  static async getOrderDetails(req, res, next) {
    const { orderId } = req.params;
    const userId = req.user.id;

    try {
      const order = await OrderModel.findById(orderId);

      // Ensure the user is requesting their own order, or is an admin/leader
      if (!order || (req.user.role !== 'admin' && req.user.role !== 'leader' && order.user_id !== userId)) {
        return res.status(404).json({ message: 'Order not found' });
      }

      const items = await OrderItemModel.getItemsByOrderId(orderId);
      res.json({ ...order, items });
    } catch (error) {
      next(error);
    }
  }

  static async getAllOrders(req, res, next) {
    try {
      const { page = 1, limit = 10, search, status } = req.query;
      const results = await OrderModel.findAll({ page, limit, search, status });
      res.json({
        success: true,
        data: results.orders,
        pagination: results.pagination
      });
    } catch (error) {
      next(error);
    }
  }

  static async updateOrderStatus(req, res, next) {
    const { orderId } = req.params;
    const { status } = req.body;
    try {
      const success = await OrderModel.updateStatus(orderId, status);
      if (success) {
        // Get the order to find the user
        const order = await OrderModel.findById(orderId);
        if (order && order.user_id) {
          const statusTranslations = {
            pending: 'قيد المراجعة',
            paid: 'مدفوع',
            cancelled: 'ملغي',
            fulfilled: 'مكتمل',
            refunded: 'مسترجع'
          };
          const arabicStatus = statusTranslations[status] || status;
          // Send notification to the customer
          try {
            await NotificationService.sendToUser(order.user_id, {
              title: 'تحديث حالة الطلب',
              body: `تم تحديث حالة طلبك رقم ${orderId.substring(0, 8)} إلى: ${arabicStatus}`
            }, { orderId: orderId, type: 'order_status_update' });
          } catch (notificationError) {
            logger.error('Failed to send notification for order status update:', notificationError);
          }
        }
        res.json({ success: true, message: 'Order status updated successfully.' });
      } else {
        res.status(404).json({ success: false, message: 'Order not found.' });
      }
    } catch (error) {
      next(error);
    }
  }

  // New method to update order items
  static async updateOrderItems(req, res, next) {
    try {
      const { orderId } = req.params;
      const userId = req.user.id;
      const { items: itemsToUpdate, shipping_address_line1, shipping_city, phone_number } = req.body;

      const order = await OrderModel.findById(orderId);
      if (!order) {
        throw new AppError('Order not found', 404);
      }
      if (req.user.role !== 'admin' && req.user.role !== 'leader') {
        throw new AppError('Unauthorized to update order', 403);
      }

      // 1. Update order details (address)
      const orderUpdateData = {};
      if (shipping_address_line1 !== undefined) orderUpdateData.shipping_address_line1 = shipping_address_line1;
      if (shipping_city !== undefined) orderUpdateData.shipping_city = shipping_city;
      if (phone_number !== undefined) orderUpdateData.phone_number = phone_number;

      if (Object.keys(orderUpdateData).length > 0) {
        await OrderModel.update(orderId, orderUpdateData);
        logger.info('Order details updated', { orderId, updatedBy: userId, changes: orderUpdateData });
      }

      // 2. Update order items
      if (itemsToUpdate && Array.isArray(itemsToUpdate)) {
        for (const itemData of itemsToUpdate) {
          const { id, title_snapshot, price_snapshot, quantity } = itemData;
          if (!id) continue;
          const updateData = {};
          if (title_snapshot !== undefined) updateData.title_snapshot = title_snapshot;
          if (price_snapshot !== undefined) updateData.price_snapshot = price_snapshot;
          if (quantity !== undefined) updateData.quantity = quantity;
          if (Object.keys(updateData).length > 0) {
            await OrderItemModel.update(id, updateData);
          }
        }
        logger.info('Order items updated', { orderId, updatedBy: userId, itemCount: itemsToUpdate.length });
      }

      // 3. Recalculate totals
      const allOrderItems = await OrderItemModel.getItemsByOrderId(orderId);
      const subtotal = allOrderItems.reduce((sum, item) => sum + (item.price_snapshot * item.quantity), 0);
      
      const currentOrder = await OrderModel.findById(orderId); // get latest order data
      const shipping = parseFloat(currentOrder.shipping) || 0;
      const tax = parseFloat(currentOrder.tax) || 0;
      const total = subtotal + shipping + tax;

      await OrderModel.updateTotals(orderId, subtotal, total);
      logger.info('Order totals recalculated', { orderId, newTotal: total });

      const finalOrder = await OrderModel.findById(orderId);
      finalOrder.items = allOrderItems; // attach items for response

      if (order && order.user_id) {
        try {
          await NotificationService.sendToUser(order.user_id, {
              title: 'تحديث أسعار الطلب',
              body: `تم تحديث أسعار بعض المنتجات في طلبك رقم ${orderId.substring(0, 8)}.`
          }, { orderId: orderId, type: 'order_price_update' });
        } catch (notificationError) {
          logger.error('Failed to send notification for order price update:', notificationError);
        }
      }

      res.json({
        success: true,
        message: 'Order updated successfully',
        data: finalOrder
      });
    } catch (error) {
      next(error);
    }
  }
}





module.exports = OrderController;
