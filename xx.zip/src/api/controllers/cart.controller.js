
const CartModel = require('../models/cart.model');
const CartItemModel = require('../models/cartItem.model');
const { AppError } = require('../../middleware/error.middleware');
const { logger } = require('../../utils/logger');
const { executeQuery, executeQueryOne, getPaginatedResults } = require('../../utils/database');

class CartController {
  // Get user's active cart
  static async getCart(req, res, next) {
    try {
      const userId = req.user.id;

      // Get or create active cart
      let cart = await CartModel.findActiveByUserId(userId);
      
      if (!cart) {
        cart = await CartModel.create({ user_id: userId, status: 'active' });
      }

      // Get cart items
      const cartItems = await CartItemModel.findByCartId(cart.id);

      // Calculate totals
      const subtotal = cartItems.reduce((sum, item) => {
        return sum + (item.price_snapshot * item.quantity);
      }, 0);

      res.json({
        success: true,
        data: {
          cart: {
            id: cart.id,
            status: cart.status,
            created_at: cart.created_at,
            updated_at: cart.updated_at
          },
          items: cartItems,
          summary: {
            item_count: cartItems.length,
            subtotal: parseFloat(subtotal.toFixed(2)),
            currency: cartItems[0]?.currency || 'USD'
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Add item to cart
  static async addItem(req, res, next) {
    try {
      const userId = req.user.id;
      const { provider, product_url, quantity, title_snapshot, price_snapshot, currency, attributes, note } = req.body;

      // Get or create active cart
      let cart = await CartModel.findActiveByUserId(userId);
      
      if (!cart) {
        cart = await CartModel.create({ user_id: userId, status: 'active' });
      }

      // Check if item already exists in cart
      const existingItem = await CartItemModel.findByCartAndProduct(cart.id, provider, product_url);

      if (existingItem) {
        // Update quantity if item exists
        const newQuantity = existingItem.quantity + quantity;
        if (newQuantity > 9999) {
          throw new AppError('Quantity cannot exceed 9999', 400);
        }

        const updatedItem = await CartItemModel.update(existingItem.id, {
          quantity: newQuantity,
          title_snapshot: title_snapshot || existingItem.title_snapshot,
          price_snapshot: price_snapshot || existingItem.price_snapshot,
          currency: currency || existingItem.currency,
          attributes: attributes || existingItem.attributes
        });

        logger.info('Cart item quantity updated', { 
          userId, 
          cartId: cart.id, 
          itemId: updatedItem.id, 
          newQuantity 
        });

        return res.json({
          success: true,
          message: 'Item quantity updated in cart',
          data: { item: updatedItem }
        });
      }

      // Create new cart item
      const newItem = await CartItemModel.create({
        cart_id: cart.id,
        provider,
        product_url,
        quantity,
        title_snapshot,
        price_snapshot,
        currency,
        attributes,
        note
      });

      logger.info('Item added to cart', { 
        userId, 
        cartId: cart.id, 
        itemId: newItem.id, 
        provider, 
        quantity 
      });

      res.status(201).json({
        success: true,
        message: 'Item added to cart successfully',
        data: { item: newItem }
      });
    } catch (error) {
      next(error);
    }
  }

  // Update cart item
  static async updateItem(req, res, next) {
    try {
      const userId = req.user.id;
      const { itemId } = req.params;
      const { quantity, title_snapshot, price_snapshot, currency, attributes, note } = req.body;

      // Verify cart ownership
      const cartItem = await CartItemModel.findById(itemId);
      if (!cartItem) {
        throw new AppError('Cart item not found', 404);
      }

      const cart = await CartModel.findById(cartItem.cart_id);
      if (!cart || cart.user_id !== userId) {
        throw new AppError('Unauthorized access to cart item', 403);
      }

      // Validate quantity
      if (quantity && (quantity < 1 || quantity > 9999)) {
        throw new AppError('Quantity must be between 1 and 9999', 400);
      }

      // Update item
      const updateData = {};
      if (quantity !== undefined) updateData.quantity = quantity;
      if (title_snapshot !== undefined) updateData.title_snapshot = title_snapshot;
      if (price_snapshot !== undefined) updateData.price_snapshot = price_snapshot;
      if (currency !== undefined) updateData.currency = currency;
      if (attributes !== undefined) updateData.attributes = attributes;
      if (note !== undefined) updateData.note = note;

      const updatedItem = await CartItemModel.update(itemId, updateData);

      logger.info('Cart item updated', { 
        userId, 
        cartId: cart.id, 
        itemId, 
        updatedFields: Object.keys(updateData) 
      });

      res.json({
        success: true,
        message: 'Cart item updated successfully',
        data: { item: updatedItem }
      });
    } catch (error) {
      next(error);
    }
  }

  // Remove item from cart
  static async removeItem(req, res, next) {
    try {
      const userId = req.user.id;
      const { itemId } = req.params;

      // Verify cart ownership
      const cartItem = await CartItemModel.findById(itemId);
      if (!cartItem) {
        throw new AppError('Cart item not found', 404);
      }

      const cart = await CartModel.findById(cartItem.cart_id);
      if (!cart || cart.user_id !== userId) {
        throw new AppError('Unauthorized access to cart item', 403);
      }

      // Remove item
      await CartItemModel.delete(itemId);

      logger.info('Item removed from cart', { 
        userId, 
        cartId: cart.id, 
        itemId, 
        provider: cartItem.provider 
      });

      res.json({
        success: true,
        message: 'Item removed from cart successfully'
      });
    } catch (error) {
      next(error);
    }
  }

  // Clear cart
  static async clearCart(req, res, next) {
    try {
      const userId = req.user.id;

      // Get active cart
      const cart = await CartModel.findActiveByUserId(userId);
      if (!cart) {
        throw new AppError('No active cart found', 404);
      }

      // Remove all items
      await CartItemModel.deleteByCartId(cart.id);

      logger.info('Cart cleared', { userId, cartId: cart.id });

      res.json({
        success: true,
        message: 'Cart cleared successfully'
      });
    } catch (error) {
      next(error);
    }
  }

  // Get cart summary
  static async getCartSummary(req, res, next) {
    try {
      const userId = req.user.id;

      // Get active cart
      const cart = await CartModel.findActiveByUserId(userId);
      if (!cart) {
        return res.json({
          success: true,
          data: {
            cart: null,
            items: [],
            summary: {
              item_count: 0,
              subtotal: 0,
              currency: 'USD'
            }
          }
        });
      }

      // Get cart items
      const cartItems = await CartItemModel.findByCartId(cart.id);

      // Calculate totals
      const subtotal = cartItems.reduce((sum, item) => {
        return sum + (item.price_snapshot * item.quantity);
      }, 0);

      // Group by provider
      const itemsByProvider = cartItems.reduce((acc, item) => {
        if (!acc[item.provider]) {
          acc[item.provider] = [];
        }
        acc[item.provider].push(item);
        return acc;
      }, {});

      res.json({
        success: true,
        data: {
          cart: {
            id: cart.id,
            status: cart.status,
            created_at: cart.created_at,
            updated_at: cart.updated_at
          },
          items: cartItems,
          summary: {
            item_count: cartItems.length,
            subtotal: parseFloat(subtotal.toFixed(2)),
            currency: cartItems[0]?.currency || 'USD',
            by_provider: Object.keys(itemsByProvider).map(provider => ({
              provider,
              item_count: itemsByProvider[provider].length,
              subtotal: parseFloat(itemsByProvider[provider].reduce((sum, item) => 
                sum + (item.price_snapshot * item.quantity), 0).toFixed(2))
            }))
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Move cart to ordered status (when order is created)
  static async markAsOrdered(cartId) {
    try {
      await CartModel.updateStatus(cartId, 'ordered');
      logger.info('Cart marked as ordered', { cartId });
      return true;
    } catch (error) {
      logger.error('Error marking cart as ordered:', error.message);
      throw error;
    }
  }

  // Abandon cart (cleanup old carts)
  static async abandonCart(cartId) {
    try {
      await CartModel.updateStatus(cartId, 'abandoned');
      logger.info('Cart marked as abandoned', { cartId });
      return true;
    } catch (error) {
      logger.error('Error abandoning cart:', error.message);
      throw error;
    }
  }

  // Get cart history
  static async getCartHistory(req, res, next) {
    try {
      const userId = req.user.id;
      const { page = 1, limit = 10, status } = req.query;

      // Build query
      let whereClause = 'WHERE user_id = ?';
      let params = [userId];

      if (status) {
        whereClause += ' AND status = ?';
        params.push(status);
      }

      const baseQuery = `SELECT * FROM carts ${whereClause}`;
      const offset = (page - 1) * limit;
      
      // Get carts
      const [carts] = await executeQuery(
        `${baseQuery} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
        [...params, parseInt(limit), offset]
      );

      // Get total count
      const [countResult] = await executeQuery(
        `SELECT COUNT(*) as total FROM carts ${whereClause}`,
        params
      );

      const total = countResult.total;
      const totalPages = Math.ceil(total / limit);

      // Get items for each cart
      const cartsWithItems = await Promise.all(
        carts.map(async (cart) => {
          const items = await CartItemModel.findByCartId(cart.id);
          const subtotal = items.reduce((sum, item) => 
            sum + (item.price_snapshot * item.quantity), 0);
          
          return {
            ...cart,
            items,
            summary: {
              item_count: items.length,
              subtotal: parseFloat(subtotal.toFixed(2))
            }
          };
        })
      );

      res.json({
        success: true,
        data: cartsWithItems,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          totalPages,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Merge guest cart with user cart (for when guest user logs in)
  static async mergeGuestCart(userId, guestCartItems) {
    try {
      if (!guestCartItems || guestCartItems.length === 0) {
        return;
      }

      // Get or create user's active cart
      let userCart = await CartModel.findActiveByUserId(userId);
      if (!userCart) {
        userCart = await CartModel.create({ user_id: userId, status: 'active' });
      }

      // Merge items
      for (const guestItem of guestCartItems) {
        const existingItem = await CartItemModel.findByCartAndProduct(
          userCart.id, 
          guestItem.provider, 
          guestItem.product_url
        );

        if (existingItem) {
          // Update quantity
          const newQuantity = existingItem.quantity + guestItem.quantity;
          await CartItemModel.update(existingItem.id, { quantity: newQuantity });
        } else {
          // Add new item
          await CartItemModel.create({
            cart_id: userCart.id,
            provider: guestItem.provider,
            product_url: guestItem.product_url,
            quantity: guestItem.quantity,
            title_snapshot: guestItem.title_snapshot,
            price_snapshot: guestItem.price_snapshot,
            currency: guestItem.currency,
            attributes: guestItem.attributes
          });
        }
      }

      logger.info('Guest cart merged with user cart', { userId, itemCount: guestCartItems.length });
    } catch (error) {
      logger.error('Error merging guest cart:', error.message);
      throw error;
    }
  }
}

module.exports = CartController;

