const { pool } = require('../config/database');
const { logger } = require('./logger');

// Execute a query with parameters
const executeQuery = async (query, params = []) => {
  try {
    const [rows] = await pool.execute(query, params);
    return rows;
  } catch (error) {
    logger.error('Database query error:', { query, params, error: error.message });
    throw error;
  }
};

// Execute a query and return the first row
const executeQueryOne = async (query, params = []) => {
  try {
    const [rows] = await pool.execute(query, params);
    return rows[0] || null;
  } catch (error) {
    logger.error('Database query error:', { query, params, error: error.message });
    throw error;
  }
};

// Execute a transaction
const executeTransaction = async (queries) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    
    const results = [];
    for (const { query, params = [] } of queries) {
      const [result] = await connection.execute(query, params);
      results.push(result);
    }
    
    await connection.commit();
    return results;
  } catch (error) {
    await connection.rollback();
    logger.error('Transaction error:', error.message);
    throw error;
  } finally {
    connection.release();
  }
};

// Build pagination query
const buildPaginationQuery = (baseQuery, options = {}) => {
  const {
    page = 1,
    limit = 10,
    sort_by = 'created_at',
    sort_order = 'desc'
  } = options;

  const offset = (page - 1) * limit;
  const orderBy = `ORDER BY ${sort_by} ${sort_order.toUpperCase()}`;
  const limitClause = `LIMIT ${limit} OFFSET ${offset}`;

  return {
    dataQuery: `${baseQuery} ${orderBy} ${limitClause}`,
    countQuery: baseQuery.replace(/SELECT.*FROM/, 'SELECT COUNT(*) as total FROM'),
    pagination: { page, limit, sort_by, sort_order }
  };
};

// Get paginated results
const getPaginatedResults = async (baseQuery, options = {}) => {
  try {
    const { dataQuery, countQuery, pagination } = buildPaginationQuery(baseQuery, options);
    
    const [data, countResult] = await Promise.all([
      executeQuery(dataQuery),
      executeQueryOne(countQuery)
    ]);

    const total = countResult.total;
    const totalPages = Math.ceil(total / pagination.limit);
    const hasNextPage = pagination.page < totalPages;
    const hasPrevPage = pagination.page > 1;

    return {
      data,
      pagination: {
        ...pagination,
        total,
        totalPages,
        hasNextPage,
        hasPrevPage,
        nextPage: hasNextPage ? pagination.page + 1 : null,
        prevPage: hasPrevPage ? pagination.page - 1 : null
      }
    };
  } catch (error) {
    logger.error('Pagination query error:', error.message);
    throw error;
  }
};

// Build search query
const buildSearchQuery = (baseQuery, searchFields, searchTerm) => {
  if (!searchTerm || !searchFields.length) {
    return baseQuery;
  }

  const searchConditions = searchFields.map(field => 
    `${field} LIKE ?`
  ).join(' OR ');

  const searchQuery = baseQuery.includes('WHERE') 
    ? `${baseQuery} AND (${searchConditions})`
    : `${baseQuery} WHERE (${searchConditions})`;

  const searchParams = searchFields.map(() => `%${searchTerm}%`);
  
  return { query: searchQuery, params: searchParams };
};

// Sanitize SQL input (basic protection)
const sanitizeInput = (input) => {
  if (typeof input !== 'string') return input;
  
  // Remove SQL injection patterns
  const dangerousPatterns = [
    /(\b(union|select|insert|update|delete|drop|create|alter|exec|execute|script)\b)/gi,
    /(--|#|\/\*|\*\/|;)/g,
    /(\b(and|or)\b\s+\d+\s*=\s*\d+)/gi
  ];
  
  let sanitized = input;
  dangerousPatterns.forEach(pattern => {
    sanitized = sanitized.replace(pattern, '');
  });
  
  return sanitized.trim();
};

// Validate UUID format
const isValidUUID = (uuid) => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
};

// Build WHERE clause for multiple conditions
const buildWhereClause = (conditions) => {
  if (!conditions || Object.keys(conditions).length === 0) {
    return { query: '', params: [] };
  }

  const whereParts = [];
  const params = [];

  Object.entries(conditions).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      if (Array.isArray(value)) {
        whereParts.push(`${key} IN (${value.map(() => '?').join(',')})`);
        params.push(...value);
      } else {
        whereParts.push(`${key} = ?`);
        params.push(value);
      }
    }
  });

  const whereClause = whereParts.length > 0 ? `WHERE ${whereParts.join(' AND ')}` : '';
  
  return { query: whereClause, params };
};

module.exports = {
  executeQuery,
  executeQueryOne,
  executeTransaction,
  buildPaginationQuery,
  getPaginatedResults,
  buildSearchQuery,
  sanitizeInput,
  isValidUUID,
  buildWhereClause
};

